#ifndef LX16_H
#define LX16_H

#include "pico/stdlib.h"
#include "hardware/clocks.h" // INDISPENSABLE pour set_sys_clock_khz
// Configuration des Pins (selon ton PCB corrigé par PIO)
#define PIN_TX 1
#define PIN_RX 0
#define SENS_PIN 2
#define BAUD 115200

// IDs Moteurs    A PROGRAMMER !
#define ID_LEVE_GG 2
#define ID_LEVE_GC 3
#define ID_LEVE_DC 4
#define ID_LEVE_DD 5
#define ID_TOURNE_GG 6
#define ID_TOURNE_GC 7
#define ID_TOURNE_DC 8
#define ID_TOURNE_DD 9
#define ID_CURSEUR_D 10
#define ID_CURSEUR_G 11

// POSITIONS BASSES DES SERVOS LEVEURS DES BRAS  A CALIBRER  !!
#define BAS_LEVE_GG 400
#define BAS_LEVE_GC 400 
#define BAS_LEVE_DC 400
#define BAS_LEVE_DD 400

// POSITIONS DE REPOS, HAUTE DES SERVOS LEVEURS DE BRAS   A CALIBRER  !!
#define REPOS_LEVE_GG 600
#define REPOS_LEVE_GC 600
#define REPOS_LEVE_DC 600
#define REPOS_LEVE_DD 600

// POSITION LEVEE PROPICE A LA ROTATION DES SERVOS LEVEURS DE BRAS  A CALIBRER  !!
#define HAUT_LEVE_GG 500
#define HAUT_LEVE_GC 500
#define HAUT_LEVE_DC 500
#define HAUT_LEVE_DD 500

// DIFFERENTES POSITIONS DES SERVOS MANIPULANT LES CURSEURS   A CALIBRER  !!
#define REPOS_CURSEUR_D 400
#define REPOS_CURSEUR_G 400
#define ACTIF_CURSEUR_D 600
#define ACTIF_CURSEUR_G 600

// POSITIONS DE REPOS DES SERVO TOURNEURS DE NOISETTES   A CALIBRER  !!
#define REPOS_TOURNE_DD 400
#define REPOS_TOURNE_DC 400
#define REPOS_TOURNE_GC 400
#define REPOS_TOURNE_GG 400

// POSITIONS TORUNEES DES SERVOS TOURNEURS DE NOISETTES   A CALIBRER  !!
#define ACTIF_TOURNE_DD 600
#define ACTIF_TOURNE_DC 600
#define ACTIF_TOURNE_GC 600
#define ACTIF_TOURNE_GG 600

void lx16_init();
void lx16_load(uint8_t id);
void lx16_move(uint8_t id, int16_t position, uint16_t time);

#endif